/// Supabase public client configuration.
/// A publishable/anon key is designed to be used by client apps.
/// NEVER put a service_role or secret key in an Android application.
class AppConfig {
  static const supabaseUrl = 'https://gjxrctfakrvnjkpmsmsg.supabase.co';
  static const supabasePublishableKey = 'sb_publishable_BYGWFgyYwB9--oPPVIY-Pg_VSCj0Qlk';
  static const appName = 'AGC Management System';
  static const currency = 'SAR';
}
